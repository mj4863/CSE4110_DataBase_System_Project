# Database Project #2
## 20212020 박민준

### [SELECT QUERY TYPES]
QUERY TYPES SELECT 시, 0부터 7 이내의 값만 입력하세요!
(해당 크기의 값을 벗어나면 invalid한 값이라고 출력됩니다.)

### Query3
실행 시, k는 50 이내로 입력하세요.
해당 크기 내에서만 유효한 데이터가 존재합니다.

### Query6
실행 시, YYYY-MM-DD의 형태로 입력하세요.
해당 형식과 범위를 벗어나면 invalid한 값이라고 출력됩니다.

### Query7
새로운 에이전트를 추가할 때, 유일한 AgentID, AgentName, PhoneNumber를 입력하세요.
중복된 AgentID를 입력하면 에러가 발생합니다.